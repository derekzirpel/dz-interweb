<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * Elementor
 */
require ('elementor/extend-elementor.php');