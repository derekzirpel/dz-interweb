jQuery(function($){
	
	$(document).ready(function() {
		$('.toggle-menu').jPushMenu();
	});
	
});