jQuery( function( $ ){
	$("#contactForm").validate();
});