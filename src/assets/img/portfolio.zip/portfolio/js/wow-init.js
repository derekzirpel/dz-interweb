

//WOW.js init

jQuery(function($) {

	wow = new WOW( { offset: 250 } )
 	wow.init(); 

});